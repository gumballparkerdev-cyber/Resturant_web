import logo from './logo.svg';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Menu from './pages/Menu';
import About from './pages/About';
import Gallery from './pages/Gallery';
import Reviews from './pages/Reviews';
// import Reservation from './pages/Reservation';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Footer from './components/Footer';
import { CartProvider } from './context/CartContext';
import { ThemeProvider } from './context/ThemeContext';
import Toast from './components/Toast';



function App() {
  return (
    <div className="App">
   
      <ThemeProvider>
        <CartProvider>
          <Router>
            <Navbar />
            <Toast />
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/menu" element={<Menu />} />
              <Route path="/about" element={<About />} />
              <Route path="/gallery" element={<Gallery />} />
              <Route path="/reviews" element={<Reviews />} />
              {/* <Route path="/reservation" element={<Reservation />} /> */}
            </Routes>
            <Footer />
          </Router>
        </CartProvider>
      </ThemeProvider>
    </div>
  );
}

export default App;
